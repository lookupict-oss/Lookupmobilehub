# Lookup Mobile Hub: everything in one package

**Easiest: use `0-ONE-REPOSITORY.zip`.** It is everything arranged as one GitHub repository, ready for GitHub + Render + Vercel. Open its `README.md` and follow Steps 1 to 4.

The other three zips hold the same parts separately:

| Zip | What's in it |
|---|---|
| `1-admin-server.zip` | Admin panel, server/API/database, AI support, WhatsApp assistant, funding, translations, deploy files |
| `2-android-app.zip` | The Android project (API 36) and the `play-store/` kit |
| `3-website.zip` | Landing page, download page, privacy and delete-account pages, web app, all translating into the chosen language |

The website and the Android app both talk to the server: same accounts, wallets, support and languages, all controlled from the admin panel.

Honest limits: card funding, SMS codes and vendor delivery need real providers (do not submit to Google Play before that); the single-file database is for launch, not millions of users; the Android build has not been compiled where it was written, so the first GitHub run is its first real test; the privacy policy is a template to complete and have reviewed; downloaded PDF receipts stay English (the built-in PDF writer only handles basic Latin text).
